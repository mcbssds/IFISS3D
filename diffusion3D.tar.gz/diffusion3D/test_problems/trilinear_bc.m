function bc = specific_bc3D(xbd,ybd,zbd)
%TRILINEAR_BC applies boundary condition for trilinear solution
%   bc = specific_bc3D(xbd,ybd,zbd);
%   inputs:
%          xbd          x boundary coordinate vector
%          ybd          y boundary coordinate vector 
%          zbd          z boundary coordinate vector 
% IFISS function: DJS; 10 January 2023
% Copyright (c)  2022  G.Papanikos,  C.E. Powell, D.J. Silvester

bc= -(xbd-1).*(ybd-1).*(zbd-1);
return
