3     % problem
2     % grid parameter
0     % direct solver switch 1/0
2     % error estimation strategy
0     % include boundary correction 1/0

%% data file for third test problem
