2     % problem
5     % grid parameter
1     % Q1/Q2 switch
0     % save results 1/0
1     % direct solver switch 1/0
2     % error estimation strategy
1     % include boundary correction 1/0

%% data file for second test problem
